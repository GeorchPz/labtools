# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 14:07:42 2020

@author: Jorge Pottiez López-Jurado
"""

import pandas as pd

import sigfig
import lib.uncert_manager as unc_manag
import lib.xcl_manager as xl_ed
from lib.files_manager import name2path, get_data_n_uncert


def sqrt(x): return x**(1/2)


'''Rounders: single values & arrays'''
def rounder(value, uncert):
    # Normal rounding cut-off, add: cutoff = 29
    # Possible change in notation, add: notation = 'sci'
    return sigfig.round(value, uncert, cutoff=29)


def arr_rounder(value_arr, uncert_arr): return list(
    map(rounder, value_arr, uncert_arr))


def exceler(variables, form_names, formulas_sy, data):
    '''Calculates the output values of a formula for given arrays'''
    variab_data, related_uncert_data = get_data_n_uncert(variables, data)
    # Lambdifies formulas
    f_lamb, δf_lamb = unc_manag.lamdifier(
        variables, *formulas_sy)
    # Unpack formulas' names
    main_f, δf = form_names
    
    # Calculations (*args allows the array to be unpacked)
    main_f_arr = f_lamb(*variab_data)
    δf_arr = δf_lamb(*variab_data, *related_uncert_data)
    
    # Add columns to data
    data[main_f + ' (UNITS)'] = main_f_arr
    data[δf]                  = δf_arr
    
    form_data_column =  main_f, main_f_arr, δf_arr
    
    # Rounding columns
    data[main_f + ' ± ' + δf] = arr_rounder(main_f_arr, δf_arr)
    
    return data, form_data_column


def averager(form_data_column):
    '''Calculates various types of means'''
    # Renaming
    name, f, δf = form_data_column

    # Average & its error
    def av(x): return sum(x) / len(x)
    def δav(δx): return sqrt(sum(δx**2)) / len(δx)
    # Weight & weighted average formulas
    def w(δx): return 1/(δx**2)
    def w_av(x, δx): return sum(x*w(δx)) / sum(w(δx))
    def w_δav(δx): return 1 / sqrt(sum(w(δx)))
    # Relative uncertainty
    def rel_un(x, δx): return str(round(δx/x*100, 2))+'%'

    # Standard mean
    f_m, σf_m = av(f), δav(δf)
    # Weighted mean
    f_wm = w_av(f, δf)
    σf_wm = w_δav(δf)

    def av_2in1(x, δx):
        '''Returns rounded values of the type x ± δx & its relative uncert'''
        round_x_δx = rounder(x, δx)
        x, δx = list(map(float, round_x_δx.split(' ± ')))
        return round_x_δx, rel_un(x, δx)

    return {
        f'({name})': ('Mean : m =', 'Rel.uncert: ι ='),
        'Standard': av_2in1(f_m, σf_m),
        'Weighted': av_2in1(f_wm, σf_wm),
        
        # f'({name})': ['Mean : m =', 'Rel.uncert: ι ='],
        # 'Standard': [*av_2in1(f_m, σf_m)],
        # 'Weighted': [*av_2in1(f_wm, σf_wm)],
        
        # {'LaTeX Formulas': formulas}
    }


def central(variab, eq, filename, Vars_dep):
    '''Pretty prints formulas & calculations + exports it to excel'''
    # Gives names & calculates formula's uncert
    form_names, formulas_sy = unc_manag.uncert_formula_calc(variab, eq, Vars_dep)
    
    # Pretty-printing & returns the latex form of the formulas
    formulas = unc_manag.exporter(form_names, formulas_sy)

    if filename != '':
        xl = pd.ExcelFile(name2path(filename))
        
        name_1st_sheet = xl.sheet_names[0]
        
        raw_data = xl.parse(name_1st_sheet)
        
        print('¡¡¡', name_1st_sheet, '!!!')
        
        ### 1st sheet
        computed_data, formulas_data_lists = exceler(variab, form_names, formulas_sy, raw_data)
        
        ### 2nd sheet
        #   Data's averages
        data_av_dict = averager(formulas_data_lists)
        
        data_average = pd.DataFrame(data_av_dict)
        #   Formulas in LaTeX
        latex_formulas = pd.DataFrame({'LaTeX Formulas': formulas})
        
        print('\n Averages (of what??):', data_average, sep='\n')
        misc = pd.concat([data_average, latex_formulas], axis='columns')

        # Save dataframes
        final_path = name2path(filename + '_©')
        writer = pd.ExcelWriter(final_path, engine='xlsxwriter')
        
        computed_data.to_excel(writer, index=False, sheet_name='Calc table')
        
        misc.to_excel(writer, index=False, sheet_name= f'Misc {eq.replace(" ","").split("=")[0]}')
        writer.save()

        # Make it pretty ;)
        xl_ed.enhancer(final_path)

    else:
        txt_file_name = 'Lab_data\\' + \
            'Formulas - ' + str(form_names[0]) + '.txt'
        txt_file = open(txt_file_name, 'w', encoding='utf-8')
        # 'w' opens file in writing mode
        # 'utf-8' encodes greek letters
        for i in formulas:
            txt_file.write(i + '\n')
        txt_file.close()


def main():
    '''Toggleable data'''  # _© → added to .xcl filename
    # Variables dependency
    # Num:           0             1
    Vars_dep = ['Dependent', 'Independent'][0]
    
    # var = 'δ,α'
    # eq = 'n = sin( (δ+α)/2 )/sin( α/2 )'
    # f_name = 'p4'

    # var = 'λ'
    # eq = 'λ^{-2} = 1/(λ**2)'
    # f_name = 'espectro_Hg'

    # var = 'M,P_t,V_g,R,T'
    # eq = 'm = (M)*P_t*V_g/(R*T)'
    # f_name = 'p5_masa'

    # var = 'V_m,A,h'
    # eq = 'V = V_m + A*h/(10**3)'
    # f_name = 'p6_volumen'

    var = 'r'
    eq = 'r⁻¹ = 1/r'
    f_name = 'p3_v_sin_tap' #, 'p3_v_sum_g', 'p3_v_sum_m'
    
    # var = 'B'
    # eq = 'k = sqrt(2*980.16*B)'
    # f_name = 'sacar_k'
    
    # for f_name in f_names:
    central(var, eq, f_name, Vars_dep)


if __name__ == '__main__':
	main()
