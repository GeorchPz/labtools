# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 23:44:02 2021

@author: Jorge Pottiez López-Jurado
"""

    
def manager(title, legend_ttl, subtitles, x_label, y_label, files_name, Mode):
    '''Centralizes al necessary progs'''
    files_name = [files_name] if type(files_name) == str else files_name
    n = len(files_name)
    
    if Mode == 'Linreg' and n == 1:
        from lib.Linreg import get_vals_Lr, plotter
        
        vals = get_vals_Lr(x_label, y_label, files_name[0])
        return plotter(*vals, title, x_label, y_label)
    
    
    elif Mode == 'Linreg' and n > 1:
        from lib.multiLinreg import get_vals_Lr, multi_plotter
        
        vals_list = [get_vals_Lr(x_label, y_label, f_name) for f_name in files_name]
        return multi_plotter(vals_list, title, legend_ttl, subtitles, x_label, y_label)    
    
    
    elif Mode == 'Plot':
        from lib.multiGrapher import get_vals, plotter
        
        vals = get_vals(x_label, y_label, files_name)
        plotter(vals, title, legend_ttl, subtitles, x_label, y_label,
                log_xscale= False, log_yscale= False)
    
    
    else:
        raise NameError(f'{Mode} is not a supported mode yet')
    
    # plt.show()

    
def main():
    '''TOGGLEABLE DATA'''
    # Num:     0         1
    Mode = ['Linreg', 'Plot'][0]
    
    # title = 'Diagramas P-V'
    # legend_ttl = r'$\bf{Volumen}$'
    # subtitles = '2.00 ± 0.10 mL'
    # x_label = 'P (atm)'
    # y_label = 'T (ºC)'
    # f_names = 'p5_P-T'
    
    
    # title = 'V vs T - rango [-1ºC, 4ºC]'
    # legend_ttl = None
    # subtitles = None
    # x_label = 'T (ºC)'
    # y_label = 'V (mL)'
    # f_names = 'p6_volumen_©_small_range'
    
    # title = '$ρ_{rel}$ vs $T$'#' - rango [-1ºC, 4ºC]'
    # legend_ttl = None
    # subtitles = None
    # x_label = 'T (ºC)'
    # y_label = '$ρ_{rel}$' #r'$ρ_{rel}$ = $\frac{ρ(T)}{ρ_{0ºC}$'
    # f_names = 'p6_densidad_©'#'_small_range'
    
    # title = 'z(r)'
    # legend_ttl = None
    # subtitles = 'Sin Tapón', 'Sumidero Grande', 'Sumidero Mediano'
    # y_label = 'z (mm)'
    # x_label = 'r (mm)'
    # f_names = 'p3_z_sin_tap_©', 'p3_z_sum_g_©', 'p3_z_sum_m_©'
    
    title = 'v(r⁻¹)'
    legend_ttl = None
    subtitles = 'Sin Tapón', 'Sumidero Grande', 'Sumidero Mediano'
    y_label = 'v (cm/s)'
    x_label = 'r⁻¹ (cm⁻¹)'
    f_names = 'p3_v_sin_tap_©', 'p3_v_sum_g_©', 'p3_v_sum_m_©'
    
    '''PROGRAM STARTER'''
    manager(title, legend_ttl, subtitles, x_label, y_label, f_names, Mode)

if __name__ == '__main__':
	main()