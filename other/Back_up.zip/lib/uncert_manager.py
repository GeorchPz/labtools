# -*- coding: utf-8 -*-
"""
Created on Tue Jun 30 21:13:45 2020

@author: jorge
"""

import sympy as sp
sp.init_printing() #SHOULD INSTALL LATEX


def eq_splitter(equation):
    '''
    Splits equation string: "f = f(x,y,...)"
    into its respective varsle ( "f" ) & formula ( "f(x,y,...)" )
    '''
    
    equation = equation.replace(' ','')
    eq_arr   = equation.split('=')
    
    if len(eq_arr)>2:
        eq_arr.pop(0)
        raise ValueError(f'Which of these equalities should be used? {eq_arr}?')
    
    quant, form = eq_arr
    
    return quant, form


def uncert_formula_calc(vars_str, eq_str, Vars_dep):
    '''Calculates formula's uncertainty (for dependent OR independent values)'''
    quant_str, form_str = eq_splitter(eq_str)
    
    # Create variables string list & symbols
    vars_list = vars_str.replace(' ', '').split(',')
    vars_symb = sp.symbols(vars_str, real = True)
        
    if len(vars_list) == 1:
        vars_symb = [vars_symb]
    
    vars_dict = {k: v for k, v in zip(vars_list, vars_symb)}
    
    # Convert formula to sympy
    form = sp.sympify(form_str, locals = vars_dict)
    
    # Create gradient vector & uncertainties list (as str & symbol lists)
    # _sy → Symbolic value of sympy
    grad_f, uncert_sy = [], []
    
    for x in vars_symb:
        grad_f.append( sp.diff(form,x) )
        uncert_sy.append( sp.Symbol('δ' + str(x), positive = True) )
    
    if Vars_dep == 'Dependent':
        # Dependent variables' formula
        δf = sum([ abs(diffx)*δx for (diffx, δx) in zip(grad_f, uncert_sy) ])
        # δf = sp.factor(δf)
        # δf = sp.simplify(δf)
        
    elif Vars_dep == 'Independent':
        # Independent variables' formula
        δf2 = sum([ (diffx*δx)**2 for (diffx, δx) in zip(grad_f, uncert_sy) ])
        δf = sp.sqrt(δf2)
        # δf = sp.simplify(δf)
        # δf = sp.powsimp(δf)
        
    else:
        raise ValueError('Are values dependent or independent?')
    
    # Array of all formulas
    quant_names = [quant_str, 'δ' + quant_str]
    formulas_sy = [form, δf]
    
    return quant_names, formulas_sy


def lamdifier(vars_str, f, δf):
    '''
    Lambdifies formulas
    That is: converts a SymPy expression into a function for numeric evaluation.
    '''
    #  variables
    vars_str = vars_str.replace(' ', '')
    uncert_arr = ['δ' + x for x in vars_str.split(',')]
    uncert_str = ','.join(uncert_arr)
    
    all_var_str = vars_str + ',' + uncert_str
    
    # Lambdas
    f_lamb = sp.lambdify(vars_str, f)
    δf_lamb = sp.lambdify(all_var_str, δf)
    
    return f_lamb, δf_lamb


def exporter(form_names, formulas):
    '''Exports the formulas by: pretty-printing & returning them in their latex form'''
    latex_form = []

    for name, expr in zip(form_names, formulas):
        eq_sy = sp.Eq( sp.Symbol(name), expr )
        # Pretty printing
        sp.pprint(eq_sy)
        # Latex Formula
        latex_form.append( sp.latex(eq_sy) )
    
    # Since LaTeX usually gives problems with greek letters,
    # we change those to their LaTeX counterparts (e.g: α --> \alpha)
    def replace_greek_to_LaTeX(text):
        for i, j in greek_to_LaTeX_dic.items():
            text = text.replace(i, j)
        return text

    greek_to_LaTeX_dic = {
        'α': '\\alpha ', 'β': '\\beta ',    'γ': '\\gamma ',   'δ': '\\delta ', 'ε': '\\epsilon ', 'ζ': '\\zeta ',
        'η': '\\eta ',   'θ': '\\theta ',   'ι': '\\iota ',    'κ': '\\kappa ', 'λ': '\\lambda ',  'μ': '\\mu ',
        'ν': '\\nu ',    'ξ': '\\xi ',      'ο': '\\omikron ', 'π': '\\pi ',    'ρ': '\\rho ',     'σ': '\\sigma ',
        'τ': '\\tau ',   'υ': '\\upsilon ', 'φ': '\\phi ',     'χ': '\\chi ',   'ψ': '\\psi ',     'ω': '\\omega ',
        # Capital letters
        'Α': '\\Alpha ', 'Β': '\\Beta ',    'Γ': '\\Gamma ',   'Δ': '\\Delta ', 'Ε': '\\Epsilon ', 'Ζ': '\\Zeta ',
        'Η': '\\Eta ',   'Θ': '\\Theta ',   'Ι': '\\Iota ',    'Κ': '\\Kappa ', 'Λ': '\\Lambda ',  'Μ': '\\Mu ',
        'Ν': '\\Nu ',    'Ξ': '\\Xi ',      'Ο': '\\Omikron ', 'Π': '\\Pi ',    'Ρ': '\\Rho ',     'Σ': '\\Sigma ',
        'Τ': '\\Tau ',   'Υ': '\\Upsilon ', 'Φ': '\\Phi ',     'Χ': '\\Chi ',   'Ψ': '\\Psi ',     'Ω': '\\Omega ',
        # Other stuff
        '⁻¹': '^{-1}', '⁻²': '^{-2}', '⁻³': '^{-3}'}
    
    latex_form = list(map(replace_greek_to_LaTeX, latex_form))

    return latex_form