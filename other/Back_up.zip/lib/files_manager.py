# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 23:00:35 2021

@author: Jorge Pottiez López-Jurado
"""

from os import path, makedirs
from re import findall

long_filedir = r'C:\Users\jorge\OneDrive\Programas_py\Lab_programs\Lab_data'
# filedir = 'Lab_data'

def name2path(name, extension = '.xlsx', filedir = long_filedir):
    '''Imports the data from an .xlsx'''
    file = name + extension
    return path.join(filedir, file)


def newpath(folder, filedir = 'Lab_data'):
    new_dir = path.join(filedir, folder)
    if not path.exists(new_dir):
        makedirs(new_dir)
    return new_dir
    
        
def vals_extracter(header):
    '''
    Finds the magnitude and the uncertainty in each header,
    by assuming that if there's a '(', it's a magnitude column
       - If value     → We assume constant uncert
       - If not value → We assume uncert isn't const
    '''
    header_split = header.split('(')
    magnitude = header_split[0]
    magnitude = magnitude.replace(' ', '')
    
    # Extract uncert(s)
    uncert_str_arr = findall(r'[-+]?\d*\.\d+|\d+', header_split[1])
    
    if len(uncert_str_arr) == 1:
        uncert = float(uncert_str_arr[0])
        return magnitude, uncert
    
    elif len(uncert_str_arr) == 0:
        # This detects magnitudes without a const uncert
        return magnitude, 'not_const'
    
    else:
        raise ValueError(f'Found several uncertainties {uncert_str_arr} for the magnitude {magnitude}')


def get_data_n_uncert(variab_str, dataframe):
    '''Arranges dataframe to get the variables & related uncertainties in arrays'''
    headers = dataframe.columns.values
    clean_df = dataframe.copy()
    
    related_uncert = {}
    for header in headers:
        if '(' in header:
            magnitude, uncert = vals_extracter(header)
            related_uncert[magnitude] = uncert
        else:
            '''We remove possible spaces from header'''
            magnitude = header.replace(' ', '')
        
        # Rename each column of the dataframe
        clean_df = clean_df.rename({header: magnitude}, axis = 'columns')
    
    # Replacing 'not const' by uncert dict
    for key in related_uncert:
        if related_uncert[key] == 'not_const':
            related_uncert[key] = clean_df['δ' + key]
    
    # Create arrays of the dataframe (in the order of the variables' string)
    var_arr = variab_str.replace(' ','').split(',') #Returns a list without spaces

    variab_data_arr = [clean_df[i] for i in var_arr]
    related_uncert_data_arr = [related_uncert[i] for i in var_arr]
    
    return variab_data_arr, related_uncert_data_arr