# -*- coding: utf-8 -*-
"""
Created on Sun Jul  5 20:31:29 2020

@author: Jorge Pottiez López-Jurado
"""

import numpy as np
from pandas import read_excel
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
from files_manager import name2path, get_data_n_uncert

import sympy as sp
'''
# fake data
X = np.linspace(0, 10, num=5)
y = 4 * X - 2 + np.random.randn(X)

u = np.polyfit(X, y, deg=1)

# prediction
X_test = np.linspace(-5, 25, num=31)
y_pred = u[0] * X_test + u[1]
'''


# Font type
font = {
        'family': 'serif',
        'color':  'black',
        'weight': 'normal',
        'size': 14
        }

def plotter(x, y, poly_model, title, x_label, y_label):
    '''Prints & plots linear regression's results'''
    
    #Linear reg. text
    main_label = '1º try'
    # (
    #     f' \n ${y.name} = ({ rounder(A,σA) }) + ({ rounder(B,σB) })·{x.name}$' +
    #     f' \n r = {round(r,3)}'
    #     ) # formated string
    
    '''FIGURE'''
    # Plot the data
    fig, ax = plt.subplots(figsize=(9,6))
    # Main slope
    # Errorbars of points
    plt.scatter(x, y, c='k')
    # plt.errorbar(x, y, xerr= σx, yerr= σy, fmt='k.',
    #               ecolor='dimgrey', capsize=4, elinewidth=2)
    myline = np.linspace(min(x), max(x), 100)
    
    x = sp.symbols('x')
    
    latex_poly = sp.printing.latex(sp.Poly(poly_model.coef,x).as_expr())
    
    plt.plot(myline, poly_model(myline), linewidth=2, color='midnightblue', alpha=0.9, 
            label= 'Regresión lineal \n' + f"${latex_poly}$")
    
    # Uncertainty of the slope
    # ax.fill_between(x, (A - σA) + (B - σB)*x, (A + σA) + (B + σB)*x, alpha=0.2,
    #                 label='Incertidumbre asociada')
    
    # Ticks, grid & plot's text
    ax.xaxis.set_minor_locator( AutoMinorLocator() )
    ax.yaxis.set_minor_locator( AutoMinorLocator() )
    plt.grid(which='major', linestyle='--', alpha=0.6)
    # plt.grid(which='minor', linestyle='-', alpha=0.3)
    
    plt.title(title, fontdict= font, fontsize=16)
    plt.xlabel(x_label, fontdict= font)
    plt.ylabel(y_label, fontdict= font)
    plt.legend(loc='best', labelspacing=1)
    # Export
    # plot_name = name2path('LinReg - ' + title.replace('$',''), extension = '.png')
    # plt.savefig(plot_name, dpi = 500, transparent = False)


def get_exp_vals(x_label, y_label, filename):
    # Find magnitudes
    x_magn = x_label.split(' ')[0]
    y_magn = y_label.split(' ')[0]
    
    if '$' in x_magn + y_magn:
        x_magn = x_magn.replace('$','')
        y_magn = y_magn.replace('$','')
    
    # Import data
    data = read_excel( name2path(filename) )
    x_y, δx_δy = get_data_n_uncert(x_magn +','+ y_magn, data)
    x, y, δx, δy = *x_y, *δx_δy
    return x, y, δx, δy

def main():
    '''TOGGLEABLE DATA'''
    # title   = 'ΔL vs ΔT PRUEBAA'
    # x_label = 'ΔT \; (ºK)'
    # y_label = 'ΔL \; (mm)'
    # filename = 'datos_aluminio'
    
    title = '$n$ vs $λ^{-2}$'
    x_label = '$λ^{-2}$ ($nm^{-2}$)'
    y_label = 'n'
    filename = 'espectro_Hg_©'
    degree = 3
    '''PROGRAM STARTER'''
    
    x = [1,2,3,5,6,7,8,9,10,12,13,14,15,16,18,19,21,22]
    y = [100,90,80,60,60,55,60,65,70,70,75,76,78,79,90,99,99,100]
    
    # x, y, δx, δy = get_exp_vals(x_label, y_label, filename)
    
    
    poly = np.polyfit(x, y, degree)
    mymodel = np.poly1d(poly)
    
    plotter(x, y, mymodel, title, x_label, y_label)
    plt.show()


if __name__ == '__main__':
	main()